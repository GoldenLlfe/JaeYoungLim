#!/usr/bin/env python
# coding: utf-8

# In[1]:


import test_package.module_a as a


# In[2]:


import test_package.module_b as b


print(a.variable_a)
print(b.variable_b)


# In[ ]:


#패키지 생성하는 방법
# 패키지 디렉토리 생성
# 패키지 디렉토리 안에 모듈 생성... 모듈 여러개 생성 가능
# import 패키지명.모듈명


# In[ ]:




